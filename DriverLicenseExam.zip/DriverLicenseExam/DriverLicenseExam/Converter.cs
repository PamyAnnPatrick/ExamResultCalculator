﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace DriverLicenseExam
{
    public class MessageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string message = "";
            switch ((MessageCodes)value)
            {
                case MessageCodes.PASS:
                    message = "Congratulation. You passed the exam.";
                    break;
                case MessageCodes.FAIL:
                    message = "Failed.Please try again.";
                    break;
                case MessageCodes.INVALID:
                    message = "Invalid data.";
                    break;
                case MessageCodes.NODATA:
                    message = "";
                    break;
            }
            return message;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {    
            throw new NotImplementedException();
        }
    }
    public class BoolImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool IsCorrect = (bool)value;
            string source = IsCorrect ? "tick.png" : "cross.png";
            return source;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

}
