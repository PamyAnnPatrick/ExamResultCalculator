﻿using System.Windows;

namespace DriverLicenseExam
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        VM vm = new VM();
        public MainWindow()
        {
            InitializeComponent();
            DataContext = vm;
        }
        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            vm.Browse();
        }
        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            vm.Reset();
        }

        private void BtnSample_Click(object sender, RoutedEventArgs e)
        {
            vm.DownloadSample();
        }
    }
}
