﻿namespace DriverLicenseExam
{
    class Result
    {
        public int QNo { get; set; }
        public string QAns { get; set; }
        public bool IsCorrect { get; set; }
    }

}
