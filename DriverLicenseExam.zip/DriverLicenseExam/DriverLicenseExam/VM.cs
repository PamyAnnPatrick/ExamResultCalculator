﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;

namespace DriverLicenseExam
{
    public enum MessageCodes
    {
        PASS,
        FAIL,
        INVALID,
        NODATA
    }
    class VM : INotifyPropertyChanged
    {
        #region Constants
        public const int SINGLE_HEIGHT = 400, DOUBLE_HEIGHT = 550, TOTAL_CT = 20, PASS_MARK = 15;
        public static readonly char[] DELIMITER = new char[] { ',', ' ', '.' };
        public static readonly char[] CORRECT_ANSWER =
               new char[] { 'B', 'D', 'A', 'A', 'C', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A' };
        #endregion

        #region Properties
        private MessageCodes messageCode= MessageCodes.NODATA;
        private string fileName, fileData;
        private int correctCt, incorrectCt, titleHeight = SINGLE_HEIGHT;
        private bool showResult, showInstruction = true;
        private KeyValuePair<string, int>[] chartData;
        public BindingList<Result> Results { get; set; } = new BindingList<Result>();
        public KeyValuePair<string, int>[] ChartData { get { return chartData; } set { chartData = value; onChange(); } }
        public int CorrectCt { get { return correctCt; } set { correctCt = value; onChange(); } }
        public int IncorrectCt { get { return incorrectCt; } set { incorrectCt = value; onChange(); } }
        public string FileName { get { return fileName; } set { fileName = value; onChange(); } }
        public int TitleHeight { get { return titleHeight; } set { titleHeight = value; onChange(); } }
        public MessageCodes MessageCode { get { return messageCode; } set { messageCode = value; onChange(); } }
        public bool ShowResult { get { return showResult; } set { showResult = value; onChange(); } }
        public bool ShowInstruction { get { return showInstruction; } set { showInstruction = value; onChange(); } }
        #endregion

        #region Methods
        public void DownloadSample()
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                if (saveFileDialog.ShowDialog() == true)
                {
                    File.WriteAllText(saveFileDialog.FileName, getdata());
                }
            }
            catch (Exception)
            { }
        }

        private string getdata()
        {
            fileData = "";
            int j = TOTAL_CT;
            for (int i = 0;( i < TOTAL_CT && j>0); i++,j--)
                fileData += (i + 1) + "." + CORRECT_ANSWER[j-1] + "\r\n";
            return fileData;
        }

        public void Reset()
        {
            ChartData = null;
            Results.Clear();
            FileName = "";
            MessageCode = MessageCodes.NODATA;
            ShowResult = false;
            TitleHeight = SINGLE_HEIGHT;
            ShowInstruction = true;
            IncorrectCt = 0;
            CorrectCt = 0;
        }
        public void Browse()
        {
            try
            {
                ChartData = null;
                Results.Clear();
                OpenFileDialog fileDialog = new OpenFileDialog();
                fileDialog.DefaultExt = ".txt";
                fileDialog.Filter = "Text documents (.txt)|*.txt";
                if (fileDialog.ShowDialog() == true)
                {
                    ShowResult = true;
                    ShowInstruction = false;
                    TitleHeight = DOUBLE_HEIGHT;
                    CorrectCt = 0;
                    FileName = Path.GetFileName(fileDialog.FileName);
                    string[] lines = File.ReadAllLines(fileDialog.FileName);
                    foreach (string line in lines)
                    {
                        string[] items = line.Split(DELIMITER, StringSplitOptions.RemoveEmptyEntries);
                        int qNo = int.Parse(items[0]);
                        string qAns = items[1];
                        if (qAns.Equals(CORRECT_ANSWER[qNo - 1].ToString()))
                        {
                            CorrectCt++;
                            Results.Add(new Result() { QNo = qNo, QAns = qAns, IsCorrect = true });
                        }
                        else
                            Results.Add(new Result() { QNo = qNo, QAns = qAns, IsCorrect = false });
                    }
                    if (CorrectCt >= PASS_MARK)
                        MessageCode = MessageCodes.PASS;
                    else                      
                        MessageCode = MessageCodes.FAIL;
                    IncorrectCt = TOTAL_CT - CorrectCt;
                    ChartData = new KeyValuePair<string, int>[]{
                               new KeyValuePair<string, int>("Correct", CorrectCt),
                               new KeyValuePair<string, int>("Incorrect", IncorrectCt)};                 
                }
            }
            catch (Exception)
            {
                Reset();
                MessageCode = MessageCodes.INVALID;            
            }
        }
        #endregion

        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        private void onChange([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
